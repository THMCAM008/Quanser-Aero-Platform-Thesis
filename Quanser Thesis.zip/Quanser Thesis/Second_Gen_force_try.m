%%Cameron Thompson: Modelling of the Quanser Aero Platform
%% System Parameters for Speed modelling
Rm = 8.4;
kt = 0.042;
km = 0.042;
kd = 1*10^(-5);
Jr = 4e-6;
mh = 0.003; 
rh = 9/1000/2; 
Jh = 0.5*mh*rh^2;
Jp = 7.2*10^(-6); 
Jeq = Jr + Jh + Jp;
Jeq1 = 1/Jeq;
%% Equations of Motion for 2 DOF platform
syms Jp Dp Ksp Kpp Kpy Vp Vy % Total inertia in pitch axis, Damping in pitch axis, Stiffness in pitch axis,Torque thrust gain from pitch, Cross-torquw thrust gain on pitch and yaw rotor, Voltage applied to pitch, Voltage Applied to yaw
syms Jy Dy Kyy Kyp % Inertia in yaw, Damping in yaw, Torque thrust gain in yaw, Cross torque gain on yaw
syms tp ty Jp Jy % Torque on pitch, Torque on yaw, total MoI on pitch, total MoI on yaw
syms Jbody Jprop Jyoke %Inertia on body, Inertia on propeller, Inertia on yoke
syms mprop rprop mbody Lbody myoke rfork t mtotal g

mtotal = mprop + mbody + myoke;
%Inertia Equations
Jprop = mprop*(rprop^2);
Jbody = mbody*((Lbody^2)/12);
Jyoke = myoke*((rfork^2)/2);

Jp = Jbody + 2*Jprop; %Total inertia acting in pitch axis
Jy = Jbody + 2*Jprop + Jyoke; %Total inertia acting in yaw axis

%Torques 
tp = Kpp*Vp + Kpy*Vy; %Torque in pitch
ty = Kpy*Vp + Kyy*Vy; %Torque in yaw 

t = [tp;ty];
syms th1 alph1 dth1 dalph1 ddth1 ddalph1 
q = [th1; alph1];
dq = [dth1;dalph1];
ddq = [ddth1;ddalph1];

%Rotations
R01 = Rotz(alph1);
R10 = transpose(R01);
R12 = Roty(th1);
R21 = transpose(R12);
R02 = R12*R01;
R20 = transpose(R02);

%Mass positions
L1_2 = [Lbody;0;0]/2;
L1_0 = R20*L1_2;

L2_2 = [-Lbody;0;0]/2;
L2_0 = R20*L2_2;

%Mass Velocities
dL1_0 = jacobian(L1_0,q)*dq;
dL2_0 = jacobian(L2_0,q)*dq;
%Angular Velocities
w01_1 = [0;0;dth1];
w01_2 = R12*w01_1;
w12_2 = [0;dalph1;0];
w02_2 = w01_2 + w12_2;

%Kinetic Energy
%For stick model
syms Jstick
Jstick = (mbody*(Lbody^2))/12;
T1 = 0.5*mbody*transpose(dL1_0)*dL1_0 + 0.5*Jstick*transpose(w02_2)*w02_2; 
T2 = 0.5*mbody*transpose(dL2_0)*dL2_0 + 0.5*Jstick*transpose(w02_2)*w02_2;
Ttot = simplify(T1+T2);
%For actual
% T1 = 0.5*mtotal*transpose(dL1_0)*dL1_0 + 0.5*Jp*transpose(w02_2)*w02_2;
% T2 = 0.5*mtotal*transpose(dL2_0)*dL2_0 + 0.5*Jy*transpose(w02_2)*w02_2;
% Ttot = simplify(T1+T2);

%Potential Energy
V1 = mtotal*g*[0 0 1]*L1_0;
V2 = mtotal*g*[0 0 1]*L2_0;
Vtot = simplify(V1+V2);
%Lagrangian
% L = simplify(Ttot - Vtot);
% 
% ddL = simplify(jacobian(L,dq)); %Partial derivative of lagragian wrt dq
% dL = jacobian(L,q); %Partial derivative of lagrangian wrt q
%% Define Mass Matrix
M = hessian(Ttot,dq);

%% Define Mass Matrix Deriv
dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);

%% Define Gravity Matrix
G = jacobian(Vtot,q);
G = simplify(G);

%% Define Coriolis Matrix
C = dM*dq - transpose(jacobian(Ttot,q));
C = simplify(C);
%% Generalised forces for Thrust
syms Lbody th1 F1 F2 alph1
r1_2 = [Lbody;0;0];
r1_0 = R20*r1_2;

r2_2 = [-Lbody;0;0];
r2_0 = R20*r2_2;

vF1 = [0;-F1;0];
vF2 = [0;0;-F2];
F1 = R20*vF1;
F2 = R20*vF2;

Q1 = transpose(F1)*diff(r1_0,th1)+ transpose(F2)*diff(r2_0,th1); %wrt th1
Q2 = transpose(F1)*diff(r1_0,alph1)+ transpose(F2)*diff(r2_0,alph1); %wrt allph

Q1 = [Q1;Q2]
%% Manipulator Equations
ManipulatorEqn = M*ddq + C + transpose(G) == Q
ddth1 = solve(ManipulatorEqn(1),ddth1);
ddalph1 = solve(ManipulatorEqn(2),ddalph1);
%% Helper Functions 
function A = Rotx(th)
    A = [1 0        0;...
         0 cos(th)  sin(th);...
         0 -sin(th)  cos(th)];
end
 
function A = Roty(th)
    A = [cos(th)  0   -sin(th);...
         0        1   0;...
         sin(th)  0   cos(th)];
end 

function A = Rotz(th)
    A = [cos(th)   sin(th) 0;... 
         -sin(th)  cos(th) 0;...
         0        0        1];
end