syms tp ty Kpp Vp Kyy Vy Kpy Kyp 
f1 = tp == Kpp*Vp +Kpy*Vy;
f2 = ty == Kyp*Vp + Kyy*Vy;
Vp1 = solve(f1,Vp);
Vy1 = solve(f2,Vy);
sub = subs(Vp1,Vy,Vy1)
stored = Vp == sub
Vp_actual = solve(stored,Vp)
Vy_actual = subs(Vy1,Vp,Vp_actual)