%% State Space representation of model
syms Dp Dy Kpp Kyy Kyp Kpy Vp Vy Jp Jy mbody Lbody th1 alph1 dth1 dalph1 Ksp b
X = [th1;alph1; dth1; dalph1];
U = [Vp;Vy];
y = [th1;alph1]
f1 = -((mbody*sin(2*th1)*Lbody^2*dalph1^2)/4 - Kpp*Vp - Kpy*Vy + Dp*dth1 + Ksp*th1)/((mbody*Lbody^2)/2 + Jp + Jy);
f2 = ((dalph1*dth1*mbody*sin(2*th1)*Lbody^2)/2 + Kyp*Vp + Kyy*Vy - Dy*dalph1)/(Jp + Jy + (Lbody^2*mbody)/4 + (Lbody^2*mbody*cos(2*th1))/4);
f = [dth1;dalph1;f1;f2];
A = jacobian(f,X);
B = jacobian(f,U);
C = jacobian(y,X);
D = jacobian(y,U);
% Parameter Values
Lbody = 0.158 ;
mbody = 1.15;
Dm = 0.00071;
g = 9.81;
b = 0;
Jp =0.0219;
Jy =0.0220;
Dp =0.00711;
Dy = 0.0220 ;
Ksp = 0.037463;
Kpp = 0.0011; % (pre-production unit: 0.0015)
Kyy = 0.0022; % (pre-production unit: 0.0040)
Kpy = 0.0021; % thrust acting on pitch from yaw (pre-production unit: 0.0020)
Kyp = -0.0027; % thrust acting on yaw from pitch (pre-production unit: -0.0017)
A = subs(A);
A1 = double(A)