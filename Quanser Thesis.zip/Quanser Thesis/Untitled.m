syms Jp dth1 th1 dalph1 alph1 Jy Ksp Dp Dy Kpp Kpy Kyp Kyy t Vp Vy ddth1 ddalph1
q = [th1;alph1];
dq = [dth1;dalph1];
ddq = [ddth1;ddalph1];
Ttot = 0.5*Jp*dth1^2 + 0.5*Jy*dalph1^2;
Vtot = 0.5*Ksp*th1^2;
M = hessian(Ttot,dq);
tp = Kpp*Vp + Kpy*Vy; %Torque in pitch
ty = Kyp*Vp + Kyy*Vy; %Torque in yaw 

% 
t = [tp;ty];

%% Define Mass Matrix Deriv
dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);

%% Define Gravity Matrix
G = jacobian(Vtot,q);
G = simplify(G);

%% Define Coriolis Matrix
C = dM*dq - transpose(jacobian(Ttot,q));
C = simplify(C);
Q1 = [-Dp*dth1;-Dy*dalph1];
%% Manipulator Equations
ManipulatorEqn = M*ddq + C + transpose(G) == Q1 + t -b*dq;
sddth1 = solve(ManipulatorEqn(1),ddth1)
sddalph1 = solve(ManipulatorEqn(2),ddalph1)