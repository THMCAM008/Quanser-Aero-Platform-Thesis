%% Quanser Aero Trajectory Optimisation %%
%% Model Parameters
dyn.mb = 1.15;  % body mass
dyn.Dt = 0.158;
dyn.Dm = 0.35;
dyn.Dz_ = 0.0211;
dyn.Dy_ = 0.0226;
dyn.Ksp_ = 0.0375;
dyn.Iz_ = 0.022;
dyn.Iy_ = 0.0219;