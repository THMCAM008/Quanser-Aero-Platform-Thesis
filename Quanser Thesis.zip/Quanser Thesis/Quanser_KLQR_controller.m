%%Quanser KLQR Controller design
syms th1 alph1 dth1 dalph1 Dp Dy Kpp Kyy Kyp Kpy Vp Vy Jp Jy mbody Lbody th1 alph1 dth1 dalph1 Ksp b
quanser_aero_parameters;
%load("Y.mat")
q = [th1;alph1];
dq = [dth1;dalph1];
Y = [th1;alph1];
J = jacobian(Y,q);
J = simplify(J);
dJ(:,1) = jacobian(J(:,1),q)*dq;
dJ(:,2) = jacobian(J(:,2),q)*dq;
X = [th1;alph1;dth1; dalph1];
U = [Vp;Vy];
y = [th1;alph1];
f1 = -(Dp*dth1 - Kpy*Vy - Kpp*Vp + Ksp*th1)/Jp;
f2 = (Kyp*Vp + Kyy*Vy - Dy*dalph1)/Jy;
f = [dth1;dalph1;f1;f2];
A = [0,0,1,0;0,0,0,1,;0,0,0,0;0,0,0,0];
%C = jacobian(y,X);
D = jacobian(y,U);
B = [0,0;0,0;1,0;0,1];
%%Controlor gains 
Q = diag([900 900 900 900]);
R = 0.09*eye(2,2);
K = lqr(A,B,Q,R)
%%
% dX = J*dq;
% P = [th1;alph1;dX(1);dX(2)];
% w = [pi;pi]-K*P;
% w1 = simplify(w);