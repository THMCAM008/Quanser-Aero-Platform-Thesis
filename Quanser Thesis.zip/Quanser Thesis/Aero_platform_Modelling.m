%%Cameron Thompson: Modelling of the Quanser Aero Platform 
% For this system I have assumed that the two fans are two equally weighted
% point masses that each act at a length LP which is the length of the
% platform from the centre of the base 

%% Thruster Modelling
%The Quanser Platform has two DC motors that power the thruster modules.
%This section will be used to get the equations of motion of the thruster 

syms Rm kt km Jm Lm % Terminal Resistance, Torque Constant, Motor back-emf constant, Rotor Inertia, Rotor Inductance  
syms kd Jh Jp %Drag resistance constant, Propeller hub inertia, Propeller Inertia
syms eb Wm dWm td Vm Im dIm tm %back-emf voltage, speed of motor shaft, torque exerted by drag; Voltage applied; Current, applied torque from motor
syms Jeq Jr Jh Jp
%System Parameters
Rm = 8.4;
kt = 0.042;
km = 0.042;
kd = 1*10^(-5);
Jr = 4e-6;
mh = 0.003; 
rh = 9/1000/2; 
Jh = 0.5*mh*rh^2;
Jp = 7.2*10^(-6); 
Jeq = Jr + Jh + Jp;
Jeq1 = 1/Jeq;
%% Generalised Co-ordinates
%Fan 1 caused the platform to rotate about the z-axis (yaw axis) by theta while the second fan
%causes the platform to move about the y-axis (pitch axis) by aplha

syms th1 alph1 dth1 dalp1h1 ddth1 ddalph1 
q = [th1; alph1];
dq = [dth1;dalph1];
ddq = [ddth1;ddalph1];
% System parameters
syms F0 F1 Mb mh Dt Dm %Thrust 1,Thrust 2,Mass of base,Mass of Hub,Thrust Displacement,Centre of mass displacement  
syms g Jr Jh Jp Jeq
syms Jbody Jyoke Jprop Jy Jp

Jp = Jbody + 2*Jprop;
Jy = Jbody + 2*Jprop + Jyoke;
I = diag([Jr Jh Jp]);
%Rotations 
R01 = Rotz(alph1); %Rotation from inertial axis to yaw axis
R10 = transpose(R01);
R02 = Roty(th1); %Rotation from interial axis to pitch axis 
R20 = transpose(R02);

%Mass positions 
L1_1 = [-Dt;0;0]; %Position of thruster 1 in pitch axis 
L1_0 = R20*L1_1;

L2_1 = [Dt;0;0]; %Position of thruster 2 in yaw axis
L2_0 = R10*L2_1;

%Mass Velocities
dL1_0 = jacobian(L1_0,q)*dq;
dL2_0 = jacobian(L2_0,q)*dq;
%Angular Velocities
w01_1 = dth1; %Velocity of thruster 1 up in z-axis
w02_1 = dalph1; %Velocity of thruster horizontally in y-axis

%Kinetic Energy
T1 = 0.5*mh*transpose(dL1_0)*dL1_0 + 0.5*transpose(w01_1)*Jeq*w01_1;
T2 = 0.5*mh*transpose(dL2_0)*dL2_0 + 0.5*transpose(w02_1)*Jeq*w02_1;
Ttot = simplify(T1+T2);

%Potential Energy
V1 = mh*g*[0 0 1]*L1_0;
V2 = mh*g*[0 0 1]*L2_0;
V3 = Mb*g*[0 0 1]*Dm;
Vtot = simplify(V1 + V2 + V3);

%Generalised Forces acting on the system:

%% Define Mass Matrix
M = hessian(Ttot,dq);

%% Define Mass Matrix Deriv
dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);

%% Define Gravity Matrix
G = jacobian(Vtot,q);
G = simplify(G);

%% Define Coriolis Matrix
C = dM*dq - transpose(jacobian(Ttot,q));
C = simplify(C);
%% Helper Functions 
function A = Rotx(th)
    A = [1 0        0;...
         0 cos(th)  sin(th);...
         0 -sin(th)  cos(th)];
end
 
function A = Roty(th)
    A = [cos(th)  0   -sin(th);...
         0        1   0;...
         sin(th)  0   cos(th)];
end 

function A = Rotz(th)
    A = [cos(th)   sin(th) 0;... 
         -sin(th)  cos(th) 0;...
         0        0        1];
end

