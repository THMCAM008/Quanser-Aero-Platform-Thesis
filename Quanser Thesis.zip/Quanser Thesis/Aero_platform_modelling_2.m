%%Cameron Thompson: Modelling of the Quanser Aero Platform
%% System Parameters for Speed modelling
% Rm = 8.4;
kt = 0.042;
% km = 0.042;
% kd = 1*10^(-5);
% Jr = 4e-6;
% mh = 0.003; 
% rh = 9/1000/2; 
% Jh = 0.5*mh*rh^2;
% Jp = 7.2*10^(-6); 
% Jeq = Jr + Jh + Jp;
% Jeq1 = 1/Jeq;
% %% Equations of Motion for 2 DOF platform
syms Jp Dp Ksp Kpp Kpy Vp Vy % Total inertia in pitch axis, Damping in pitch axis, Stiffness in pitch axis,Torque thrust gain from pitch, Cross-torquw thrust gain on pitch and yaw rotor, Voltage applied to pitch, Voltage Applied to yaw
syms Jy Dy Kyy Kyp % Inertia in yaw, Damping in yaw, Torque thrust gain in yaw, Cross torque gain on yaw
syms tp ty Jp Jy % Torque on pitch, Torque on yaw, total MoI on pitch, total MoI on yaw
syms Jbody Jprop Jyoke %Inertia on body, Inertia on propeller, Inertia on yoke
syms mprop rprop mbody Lbody myoke rfork t mtotal g b
% 
% mtotal = mprop + mbody + myoke;
% %Inertia Equations
% Jprop = mprop*(rprop^2);
% Jbody = mbody*((Lbody^2)/12);
% Jyoke = myoke*((rfork^2)/2);
% 
% Jp = Jbody + 2*Jprop; %Total inertia acting in pitch axis
% Jy = Jbody + 2*Jprop + Jyoke; %Total inertia acting in yaw axis
% 
% %Torques 
tp = Kpp*Vp + Kpy*Vy; %Torque in pitch
ty = Kyp*Vp + Kyy*Vy; %Torque in yaw 

% 
t = [tp;ty];
syms th1 alph1 dth1 dalph1 ddth1 ddalph1 
q = [th1; alph1];
dq = [dth1;dalph1];
ddq = [ddth1;ddalph1];

%Rotations
R01 = Rotz(alph1);
R10 = transpose(R01);
R12 = Roty(th1);
R21 = transpose(R12);
R02 = R12*R01;
R20 = transpose(R02);

%Mass positions
L1_2 = [Lbody;0;0]/2; %Position if fan 1 is depenedent on both transformations thus it is in frame 2 here 
L1_0 = R20*L1_2;

L2_2 = [-Lbody;0;0]/2;
L2_0 = R20*L2_2;

%Mass Velocities
dL1_0 = jacobian(L1_0,q)*dq;
dL2_0 = jacobian(L2_0,q)*dq;
%Angular Velocities
w01_1 = [0;0;dalph1];
w01_2 = R12*w01_1;
w12_2 = [0;dth1;0];
w02_2 = w01_2 + w12_2;

%Kinetic Energy
%For stick model
syms Jstick
Jstick = (mbody*(Lbody^2))/12;
T1 = 0.5*mbody*transpose(dL1_0)*dL1_0; + 0.5*Jp*transpose(w02_2)*w02_2; 
T2 = 0.5*mbody*transpose(dL2_0)*dL2_0; + 0.5*Jy*transpose(w02_2)*w02_2;
Ttot = simplify(T1+T2);

%Potential Energy
V1 = mbody*g*[0 0 1]*L1_0;
V2 = mbody*g*[0 0 1]*L2_0;
V3 = 0.5*Ksp*(th1)^2;
Vtot = simplify(V1+V2+V3);
%Lagrangian
% L = simplify(Ttot - Vtot);
% 
% ddL = simplify(jacobian(L,dq)); %Partial derivative of lagragian wrt dq
% dL = jacobian(L,q); %Partial derivative of lagrangian wrt q
%% Define Mass Matrix
M = hessian(Ttot,dq);

%% Define Mass Matrix Deriv
dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);

%% Define Gravity Matrix
G = jacobian(Vtot,q);
G = simplify(G);

%% Define Coriolis Matrix
C = dM*dq - transpose(jacobian(Ttot,q));
C = simplify(C);
%% Generalised forces for Thrust
syms  th1 F1 F2 alph1 Dm bp by
r1_2 = [Lbody;0;0];
r1_0 = R20*r1_2;

r2_2 = [-Lbody;0;0];
r2_0 = R20*r2_2;

vF1 = [0;F1;0];%F1 is force in yaw 
vF2 = [0;0;F2]; %G=F2 is force in pitch
F1 = R20*vF1;
F2 = R20*vF2;

dT11 = diff(r1_0,th1);
dT21 = diff(r1_0,alph1);

dT12 = diff(r2_0,th1);
dT22 = diff(r2_0,alph1);

%Q1 
Q1_th1 = F1(1)*dT11(1) + F1(2)*dT11(2) + F1(3)*dT11(3);
Q1_alph1 = F1(1)*dT21(1) + F1(2)*dT21(2) + F1(3)*dT21(3);

Q2_th1 = F2(1)*dT12(1) + F2(2)*dT12(2) + F2(3)*dT12(3);
Q2_alph1 = F2(1)*dT22(1) + F2(2)*dT22(2) + F2(3)*dT22(3);
Q1 = [Q1_th1;Q1_alph1];
Q2 = [Q2_th1;Q2_alph1];
Q = Q1+ Q2;
Q1 = [-Dp*dth1;-Dy*dalph1];
%% Manipulator Equations
ManipulatorEqn = M*ddq + C + transpose(G) == Q1 + t;
addth1 = solve(ManipulatorEqn(1),ddth1);
addalph1 = solve(ManipulatorEqn(2),ddalph1);
sddth1 = simplify(solve(ManipulatorEqn(1),ddth1));
sddalph1 = simplify(solve(ManipulatorEqn(2),ddalph1));
%%
Lbody = 0.158;
mbody = 1.15;
Ksp = 0.0375;
M = subs(M)
G = subs(G)
C = subs(C)
%% Equations if motion
% x = Jp*ddq(1) + Dp*dq(1) + Ksp*q(1) == tp-b*dq(1)
% y = Jy*ddq(2) + Dy*dq(2) == ty-b*dq(2)
% ddth1_act = solve(x,ddth1)
% ddalph1_act = solve(y,ddalph1)
%% Solving for b
% i = 17;  
% th1 = out.th1.signals.values(i);
% dth1 = out.dth1.signals.values(i);
% ddth1 = out.ddth1.signals.values(i);
% alph1 = out.alph1.signals.values(i);
% dalph1 = out.dalph1.signals.values(i);
% ddalph1 = out.ddalph1.signals.values(i);
% F1 = out.F1.signals.values(i);
% F2 = out.F2.signals.values(i);
% EqnForB1 = solve(ManipulatorEqn(1),b); 
% EqnForB2 = solve(ManipulatorEqn(2),b); 
% EqnForB3 = solve(ManipulatorEqn(3),b); 
% bVal1 = subs(EqnForB1);
% bVal2 = subs(EqnForB2);
% bVal3 = subs(EqnForB3);
% disp(double(bVal1))
% disp(double(bVal2))
% disp(double(bVal3))
% %% Helper Functions 
function A = Rotx(th)
    A = [1 0        0;...
         0 cos(th)  sin(th);...
         0 -sin(th)  cos(th)];
end
 
function A = Roty(th)
    A = [cos(th)  0   -sin(th);...
         0        1   0;...
         sin(th)  0   cos(th)];
end 

function A = Rotz(th)
    A = [cos(th)   sin(th) 0;... 
         -sin(th)  cos(th) 0;...
         0        0        1];
end