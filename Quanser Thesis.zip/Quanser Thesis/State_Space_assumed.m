%% State Space representation of model
syms Dp Dy Kpp Kyy Kyp Kpy Vp Vy Jp Jy mbody Lbody th1 alph1 dth1 dalph1 Ksp b
X = [th1;alph1; dth1; dalph1];
U = [Vp;Vy];
y = [th1;alph1];
f1 = -(Dp*dth1 - Kpy*Vy - Kpp*Vp + Ksp*th1)/Jp;
f2 = (Kyp*Vp + Kyy*Vy - Dy*dalph1)/Jy;
f = [dth1;dalph1;f1;f2];
A = jacobian(f,X);
B = jacobian(f,U)
C = jacobian(y,X);
D = jacobian(y,U);
% Parameter Values
Lbody = 0.158 ;
mbody = 1.15;
Jp =0.0219;
Jy =0.0220;
Dp =0.00711;
Dy = 0.0220 ;
Ksp = 0.037463;
Kpp = 0.0011; 
Kyy = 0.0022;
Kpy = 0.0021; 
Kyp = -0.0027;
A = double(subs(A));
B = double(subs(B));