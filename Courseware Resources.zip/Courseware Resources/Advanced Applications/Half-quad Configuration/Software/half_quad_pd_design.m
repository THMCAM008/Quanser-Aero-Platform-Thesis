%% Load parameters
quanser_aero_parameters;
%
%% Control Specifications
% Peak time and overshoot specifications
PO = 7.5;
tp = 1.25;
% Damping ratio from overshoot specification.
zeta = -log(PO/100) * sqrt( 1 / ( ( log(PO/100) )^2 + pi^2 ) );
% Natural frequency from specifications (rad/s)
wn = pi / ( tp * sqrt(1-zeta^2) );
% 
%% PV Design for Half-Quadrotor yaw control
kp = -Jy*wn^2/(2*Kyp)
kd = -(2*Jy*zeta*wn - Dy) / (2*Kyp)