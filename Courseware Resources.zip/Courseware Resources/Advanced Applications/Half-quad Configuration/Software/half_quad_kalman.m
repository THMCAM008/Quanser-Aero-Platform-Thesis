% Clear workspace
clear;
% Load model parameters
quanser_aero_parameters;
% 
%% Define state-space system 
% x = [psi; psi_dot]
% y = [ psi_dot; psi_ddot]
% 
% Jy*x2_ddot + Dy*x2_dot = -2*Kyp*u
% psi_ddot  = -Dy/Jy*psi_dot - 2*Kyp/Jy*u
% 
% State dimensions
nx = 2; % length of state x
ny = 2; % length of output y
nu = 1; % length of input u
nw = 1; % length of process noise w
% 
A = [0 1;
    0 -Dy/Jy];
% 
B = [0; -2*Kyp/Jy]; % nx x nu
% 
C = [0 1;
    0 -Dy/Jy]; % ny x nx 
% 
D = [0; -2*Kyp/Jy]; % ny x nu
% 
%% LQR Design
% Use full-state state-space to get optimal control gain
Q = diag([150 0]);
R = 0.01;
K = lqr(A,B,Q,R)
% 
%% Kalman Estimator
rank = rank(obsv(A,C)) % is it detectable? Necessary condition for Kalman
% define state-space and include input noise 'w'
sys_w = ss(A,[B B],C,[D D],0.002,'inputname',{'u' 'w'},'outputname','y');
% Define weighting matrices
Qn = 0.5*eye(nw,nw); % nw x nw 
% Qn = 0.01*eye(nw,nw); % nw x nw - used for simulation
Rn = diag([0.001 20]); % ny x ny
% Rn = diag([100 100]); % ny x ny - used for simulation
% Design Kalman observer
[kest,L,P,M] = kalman(sys_w,Qn,Rn);
% Save state-space matrices to these variables for the Simulink model
[ak,bk,ck,dk,Ts]=ssdata(kest);
% 
