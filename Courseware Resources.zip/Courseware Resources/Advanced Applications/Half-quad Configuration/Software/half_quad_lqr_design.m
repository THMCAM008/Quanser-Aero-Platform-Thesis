%% Load state-space model
quanser_aero_parameters;
half_quad_state_space;
% 
%% State-Feedback LQR Control Design
Q = diag([150 0]);
R = 0.01;
K = lqr(A,B,Q,R)