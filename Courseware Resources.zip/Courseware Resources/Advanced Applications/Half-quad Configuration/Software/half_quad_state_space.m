%% Load parameters
quanser_aero_parameters;
% 
%% Model
% Jy*psi_ddot + Dy*psi_dot  = tau_p + tau_y
%                           = -Kyp*Vp - Kyp*Vy
%                           = -2*Kyp*u
% where Kyp = thrust gain acting on the yaw from the pitch-oriented rotor
% 
%% State-Space Representation
A = [0 1;
    0 -Dy/Jy];
B = [0;
    -2*Kyp/Jy];
C = [1 0]; % assuming only yaw position measurement
D = 0;
% 
ss_hq = ss(A,B,C,D);

