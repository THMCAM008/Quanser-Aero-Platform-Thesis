%% Load parameters
quanser_aero_parameters;
% 
%% Model
% Jp*theta_ddot + Dp*theta_dot  = Kpp*Vp
% 
%% State-Space Representation
A = [0 1;
    -Ksp/Jp -Dp/Jp];
B = [0;
    Kpp/Jp];
C = [1 0]; % assuming only pitch position measurement
D = 0;
% 
ss_hq = ss(A,B,C,D);

