%% Load state-space model
quanser_aero_parameters;
pitch_state_space;
% 
%% State-Feedback LQR Control Design
Q = diag([250 10]);
R = 0.005;
K = lqr(A,B,Q,R)