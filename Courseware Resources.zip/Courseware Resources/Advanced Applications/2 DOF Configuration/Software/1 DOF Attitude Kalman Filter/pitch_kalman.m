% Clear workspace
clear;
% Load model parameters
quanser_aero_parameters;
% 
%% Define state-space system 
% x = [theta; theta_dot]
% y = [theta (from acc); theta_dot]
% 
% Jp*x2_ddot + Dp*x2_dot = Kyp*u
% theta_ddot = [theta_dot; -Dp/Jp*theta_dot+Kp/Jp*u]
%           = [x2 ;-Dp/Jp*x2] + [Kpp/Jp]*u 
% 
% State dimensions
nx = 2; % length of state x
ny = 2; % length of output y
nu = 1; % length of input u
nw = 1; % length of process noise w
% 
A = [0 1;
    -Ksp/Jp -Dp/Jp];
% 
B = [0; Kpp/Jp]; % nx x nu
% 
C = [1 0;
    0 1]; % ny x nx 
% 
D = [0; 0]; % ny x nu
% 
%% LQR Design
% define state-space and include process noise 'w'
% 
Q = diag([250 10]);
R = 0.005;
K = lqr(A,B,Q,R)
% 
%% Kalman Estimator
rank = rank(obsv(A,C)) % is it detectable? 
% define state-space and include input noise 'w'
sys_w=ss(A,[B B],C,[D D],0.002,'inputname',{'u' 'w'},'outputname','y');
% Define weighting matrices
Qn = 50*eye(nw,nw); % nw x nw
Rn = diag([0.1 0.005]); % ny x ny
% Design Kalman observer
[kest,L,P,M] = kalman(sys_w,Qn,Rn);
[ak,bk,ck,dk,Ts]=ssdata(kest);
% 
