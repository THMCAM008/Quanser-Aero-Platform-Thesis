figure('Color',[1,1,1]);
subplot(2,1,1);
plot(AngleResp(1:10000,1),AngleResp(1:10000,2),'r-'); 
ylabel('\theta_b (rad)');
subplot(2,1,2); 
plot(SpeedResp(1:10000,1),SpeedResp(1:10000,2),'r-'); 
ylabel('\omega (rad/s)'); xlabel('time (s)');

figure('Color',[1,1,1]);
plot(AngleResp(10001:20000,1),AngleResp(10001:20000,2),'r-'); 
ylabel('\theta_b (rad)'); xlabel('time (s)');